public class Main
{
	public static void main(String args[])
	{
		ConnexionMySQL cMySQL = new ConnexionMySQL();
		ConnexionMongoDB cMongoDB = new ConnexionMongoDB();
	}
}