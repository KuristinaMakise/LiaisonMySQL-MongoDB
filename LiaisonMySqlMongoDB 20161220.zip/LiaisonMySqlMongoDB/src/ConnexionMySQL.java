import java.sql.DriverManager;
import java.sql.ResultSet;

public class ConnexionMySQL
{
	public ConnexionMySQL()
	{
		/*String url = "jdbc:mysql://localhost:3306/Transporteur1";
		String login = "root";
		String passwd = "3306";*/
		
		/**
		 * url contenant l'ip et le nom de la database, login et password de connexion
		 */
		String url = "jdbc:mysql://25.151.228.218/Transporteur1";
		String login = "xaba";
		String passwd = "xaba";
		
		java.sql.Connection c = null;
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		
		try
		{
			// MySQL driver
			Class.forName("com.mysql.jdbc.Driver");
			// Connexion
			c = DriverManager.getConnection(url, login, passwd);
			stmt = c.createStatement();
			
			//String sql = "INSERT INTO `Trajet` (`id`,`depart`,`arrivee`,`cout`,`temps`,`gps`) VALUES (1,\"P.O. Box 885, 1348 Dui Road\",\"Ap #839-6507 Donec Rd.\",6017,35,\"-9.82013, 164.80831\");";
			//stmt.executeUpdate(sql);
			
			/**
			 * Affichage de tous les id de la database
			 */
			String sql = "SELECT * FROM Trajet";
			rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				System.out.println(rs.getString("id"));
			}
			
		} catch(Exception e)
		{
			e.printStackTrace();
		} finally
		{
			try
			{
				c.close();
				stmt.close();
			} catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
